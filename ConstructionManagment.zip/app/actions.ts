'use server';

// This file is kept for potential future server actions
// Company switching is handled client-side via NextAuth update()

